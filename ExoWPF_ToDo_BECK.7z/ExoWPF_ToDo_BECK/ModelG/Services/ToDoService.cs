﻿using ModelGlobal.Data;
using ModelGlobal.Repositories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace ModelGlobal.Services
{
    public class ToDoService : IToDoRepository<ToDo>
    {
        private static IToDoRepository<ToDo> _instance;

        public static IToDoRepository<ToDo> Instance
        {
            get { return _instance ?? (_instance = new ToDoService()); }
        }

        private SqlConnection _connection;
        private ToDoService()
        {
            _connection = new SqlConnection(@"Data Source=FORMA-VDI1106\TFTIC;Initial Catalog=ExoWPF_ToDo;User ID=sa;Password=tftic@2012");
            _connection.Open();
        }

        public void Delete(int id)
        {
            using (SqlCommand cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "Delete FROM ToDo WHERE Id = @Id";
                cmd.Parameters.AddWithValue("Id", id);
                cmd.ExecuteNonQuery();
            }
        }

        public List<ToDo> GetAll()
        {
            using (SqlCommand cmd = _connection.CreateCommand())
            {
                List<ToDo> f = new List<ToDo>();
                cmd.CommandText = "SELECT * FROM ToDo";
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        f.Add(new ToDo
                        {
                            Id = (int)dr["Id"],
                            Titre = dr["Titre"].ToString(),
                            Description = dr["Description"].ToString(),
                            IsCompleted = (bool)dr["IsCompleted"],
                            DateValidation = dr["DateValidation"] is DBNull ? null : (DateTime?)dr["DateValidation"]
                        }); ;
                    }
                }
                return f;
            }
        }

        public ToDo GetOne(int id)
        {
            using (SqlCommand cmd = _connection.CreateCommand())
            {
                ToDo t = new ToDo();
                cmd.CommandText = "SELECT * FROM ToDo";
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        t.Id = (int)dr["Id"];
                        t.Titre = dr["Titre"].ToString();
                        t.Description = dr["Description"].ToString();
                        t.IsCompleted = (bool)dr["IsCompleted"];
                        t.DateValidation = dr["DateValidation"] is DBNull ? null : (DateTime?)dr["DateValidation"];
                    }
                }
                return t;
            }
        }

        public void Insert(ToDo t)
        {
            using (SqlCommand cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "INSERT INTO ToDo (Titre, Description, IsCompleted, DateValidation) VALUES (@Titre, @Description, @IsCompleted, @DateValidation)";
                cmd.Parameters.AddWithValue("Titre", t.Titre);
                cmd.Parameters.AddWithValue("Description", t.Description);
                cmd.Parameters.AddWithValue("IsCompleted", t.IsCompleted);
                cmd.Parameters.AddWithValue("DateValidation", t.DateValidation);
                               
                cmd.ExecuteNonQuery();
            }
        }

        public void Update(ToDo t)
        {
            using (SqlCommand cmd = _connection.CreateCommand())
            {
                cmd.CommandText = "UPDATE ToDo SET Titre = @Titre, Description = @Description, IsCompleted = @IsCompleted, DateValidation = @DateValidation WHERE Id = @id";
                cmd.Parameters.AddWithValue("Titre", t.Titre);
                cmd.Parameters.AddWithValue("Description", t.Description);
                cmd.Parameters.AddWithValue("IsCompleted", t.IsCompleted);
                cmd.Parameters.AddWithValue("DateValidation", t.DateValidation);

                cmd.Parameters.AddWithValue("Id", t.Id);

                cmd.ExecuteNonQuery();
            }
        }
    }
}
