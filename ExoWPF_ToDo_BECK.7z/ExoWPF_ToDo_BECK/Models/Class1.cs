﻿using System;

namespace Models
{
    public class Class1
    {
    }
}
