﻿using ExoWPF_ToDo_BECK.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExoWPF_ToDo_BECK.Mediator.Message
{
    public class DeleteToDoMessage
    {
        public ToDoViewModel ViewModel { get; private set; }

        public DeleteToDoMessage(ToDoViewModel viewModel)
        {
            ViewModel = viewModel ?? throw new ArgumentNullException(nameof(viewModel));
        }
    }
}
