﻿using ModelLocal.Models;
using ModelLocal.Services;
using System;
using System.Collections.Generic;
using System.Text;
using Tools;

namespace ExoWPF_ToDo_BECK.ViewModels
{
    public class ToDoViewModel : ViewModelBase
    {
        #region Propriétés

        private ToDo _entity;

        public int Id
        {
            get { return _entity.Id; }
            set { _entity.Id = value; }
        }

        public string Titre
        {
            get { return _entity.Titre; }
            set { _entity.Titre = value; }

        }

        public string Description
        {
            get { return _entity.Description; }
            set { _entity.Description = value; }
        }

        public bool IsCompleted
        {
            get { return _entity.IsCompleted; }
            set { _entity.IsCompleted = value; }
        }


        public ToDoViewModel(ToDo t)
        {
            _entity = t;
        }
        #endregion

        #region Commandes
        private RelayCommand _updateCommand, _deleteCommand;

        public RelayCommand UpdateCommand
        {
            get
            {
                return _updateCommand ?? (_updateCommand = new RelayCommand(Update));
            }
        }

        public void Update()
        {

            ToDoServiceClient.Instance.Update(_entity);

            Titre = "";
            IsCompleted = false;
            //connect to Api
            //si Ok ...
            _entity.Titre = Titre;
            //Si Ko
            //Affiche Message
            //Title = _entity.Title;
        }

        public RelayCommand DeleteCommand
        {
            get
            {
                return _deleteCommand ?? (_deleteCommand = new RelayCommand(Delete));
            }
        }

        public void Delete()
        {
            ToDoServiceClient.Instance.Delete(_entity.Id);
            //GestionEvent<Film>.Instance.Send(t);

            //Repository repos = Repository.Instance;
            //repos.Delete(_entity.Id);

            //Messenger<DeleteToDoMessage>.Instance.Send(new DeleteToDoMessage(this));
        }

        private RelayCommand _toDoListCommand;
        public RelayCommand ToDoListCommand
        {
            get
            {
                return _toDoListCommand ?? (_toDoListCommand = new RelayCommand(BackToList));
            }
        }

        public void BackToList()
        {
            MainWindow mw = new MainWindow();
            //mw.DataContext = this;

            mw.Show();
        }

        #endregion

        #region Brouillon

        //private RelayCommand _addCommand, _updateCommand, _deleteCommand;

        //public RelayCommand DeleteCommand
        //{
        //    get
        //    {
        //        return _deleteCommand ?? (_deleteCommand = new RelayCommand(Delete));
        //    }
        //}

        //public RelayCommand AddCommand
        //{
        //    get
        //    {
        //        return _addCommand ?? (_addCommand = new RelayCommand(Insert));
        //    }
        //}

        //public RelayCommand UpdateCommand
        //{
        //    get
        //    {
        //        return _updateCommand ?? (_updateCommand = new RelayCommand(Update));
        //    }
        //}

        //public void Delete()
        //{

        //    ToDoServiceClient.Instance.Delete(_entity.Id);
        //    GestionEvent<Film>.Instance.Send(_entity);
        //}

        //public void Update()
        //{
        //    ToDoServiceClient.Instance.Update(_entity);

        //}

        //public void Insert()
        //{
        //    ToDoServiceClient.Instance.Insert(_entity);
        //}

        //private RelayCommand _detailCommand;
        //public RelayCommand DetailCommand
        //{
        //    get
        //    {
        //        return _detailCommand ?? (_detailCommand = new RelayCommand(Details));
        //    }
        //}

        //public void Details()
        //{
        //    DetailWindow dw = new DetailWindow();
        //    dw.DataContext = this;

        //    dw.Show();
        //}

        #endregion
    }
}
