﻿using ModelLocal.Models;
using ModelLocal.Services;
using ExoWPF_ToDo_BECK.Mediator;
using ExoWPF_ToDo_BECK.Mediator.Message;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Tools;

namespace ExoWPF_ToDo_BECK.ViewModels
{
    public class ToDoListViewModel : ViewModelCollectionBase<ToDoViewModel>
    {
        #region Propriétés
        

        private string _titre;
        public string Titre
        {
            get { return _titre; }
            set
            {
                if (_titre != value)
                {
                    _titre = value;
                    RaisePropertyChanged(nameof(Titre));
                }
            }
        }

        private bool _isCompleted;
        public bool IsCompleted
        {
            get { return _isCompleted; }
            set
            {
                if (_isCompleted != value)
                {
                    _isCompleted = value;
                    RaisePropertyChanged(nameof(IsCompleted));
                }
            }
        }

        private ObservableCollection<ToDoViewModel> _listeToDo;

        public ObservableCollection<ToDoViewModel> ListeToDo
        {
            get
            {
                return _listeToDo ??= LoadItems();
            }
        }
        #endregion

        #region Commandes

        private RelayCommand _addCommand;

        public RelayCommand AddCommand
        {
            get
            {
                return _addCommand ?? (_addCommand = new RelayCommand(Insert));
            }
        }

        public void Insert()
        {
            ToDo t = new ToDo
            {
                Titre = Titre,
                IsCompleted = IsCompleted
            };

            ToDoServiceClient.Instance.Insert(t);
            //Items = LoadItems();
            //Titre = "";
            //IsCompleted = false;
        }



        #endregion

        #region ??? GestionEvent

        //public ToDoListViewModel()
        //{
        //    GestionEvent<ToDo>.Instance.Register(GoDelete);
        //}

        //public void GoDelete(ToDo t)
        //{
        //    ToDoViewModel vm = new ToDoViewModel(t);
        //    Items = LoadItems();
        //    // Items.Remove(vf);

        //}

        #endregion

        protected override ObservableCollection<ToDoViewModel> LoadItems()
        {
            ObservableCollection<ToDoViewModel> ToDoList =
                new ObservableCollection<ToDoViewModel>(ToDoServiceClient.Instance.GetAll().Select(x => new ToDoViewModel(x)));
            return ToDoList;
        }
    }
}
