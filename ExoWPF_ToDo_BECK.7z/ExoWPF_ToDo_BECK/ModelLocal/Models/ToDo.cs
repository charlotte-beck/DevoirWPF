﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ModelLocal.Models
{
    public class ToDo
    {
        public int Id { get; set; }
        public string Titre { get; set; }
        public string Description { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? DateValidation { get; set; }
    }
}
