﻿using ModelLocal.Models;
using ModelGlobal.Repositories;
using G = ModelGlobal.Data;
using GS = ModelGlobal.Services;
using ModelLocal.Utils;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace ModelLocal.Services
{
    public class ToDoServiceClient : IToDoRepository<ToDo>
    {
        private static IToDoRepository<ToDo> _instance;
        private IToDoRepository<G.ToDo> _GlobalService;

        public static IToDoRepository<ToDo> Instance
        {
            get { return _instance ?? (_instance = new ToDoServiceClient()); }
        }

        private ToDoServiceClient()
        {
            _GlobalService = GS.ToDoService.Instance;
        }


        public void Delete(int id)
        {
            _GlobalService.Delete(id);
        }

        public List<ToDo> GetAll()
        {
            return _GlobalService.GetAll().Select(x => x.ToLocal()).ToList();
        }

        public ToDo GetOne(int id)
        {
            return _GlobalService.GetOne(id).ToLocal();
        }

        public void Insert(ToDo t)
        {
            _GlobalService.Insert(t.ToGlobal());
        }

        public void Update(ToDo t)
        {
            _GlobalService.Update(t.ToGlobal());
        }
    }
}
