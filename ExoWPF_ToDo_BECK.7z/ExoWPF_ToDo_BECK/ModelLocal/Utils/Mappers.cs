﻿using G = ModelGlobal.Data;
using C = ModelLocal.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ModelLocal.Utils
{
    public static class Mappers
    {
        public static C.ToDo ToLocal(this G.ToDo t)
        {
            return new C.ToDo
            {
                Id = t.Id,
                Titre = t.Titre,
                Description = t.Description,
                IsCompleted = t.IsCompleted,
                DateValidation = t.DateValidation
            };
        }

        public static G.ToDo ToGlobal(this C.ToDo t)
        {
            return new G.ToDo
            {
                Id = t.Id,
                Titre = t.Titre,
                Description = t.Description,
                IsCompleted = t.IsCompleted,
                DateValidation = t.DateValidation
            };
        }
    }
}
